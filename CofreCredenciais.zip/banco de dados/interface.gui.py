import PySimpleGUI as sg

sg.theme('DarkBlue3')

dados_tabela = []

cabecalhos = ['Serviço', 'Usuário']

layout = [
    [sg.Text("Serviço:", size=(10, 1)),
     sg.Input(key="-SERVICO-")],

    [sg.Text("Usuário:", size=(10, 1)),
     sg.Input(key="-USUARIO-")],

    [sg.Text("Senha:", size=(10, 1)),
     sg.Input(key="-SENHA-", password_char="*")],

    [
        sg.Button("Cadastrar"),
        sg.Button("Revelar Senha"),
        sg.Button("Editar"),
        sg.Button("Excluir"),
        sg.Button("Limpar"),
        sg.Button("Sair")
    ],

    [sg.HorizontalSeparator()],

    [sg.Table(
        values=dados_tabela,
        headings=cabecalhos,
        max_col_width=25,
        auto_size_columns=True,
        justification='center',
        num_rows=10,
        key="-TABELA-"
    )]
]

janela = sg.Window("Cofre de Credenciais", layout)

while True:

    evento, valores = janela.read()

    if evento in (sg.WINDOW_CLOSED, "Sair"):
        break

    if evento == "Cadastrar":

        if not all([valores["-SERVICO-"], valores["-USUARIO-"], valores["-SENHA-"]]):
            sg.popup_error("Serviço, Usuário e Senha são obrigatórios!")
            continue

        novo_registro = [
            valores["-SERVICO-"],
            valores["-USUARIO-"]
        ]

        dados_tabela.append(novo_registro)

        janela["-TABELA-"].update(values=dados_tabela)

        sg.popup_ok("Credencial inserida na tabela!")

    if evento == "Limpar":

        for key in ["-SERVICO-", "-USUARIO-", "-SENHA-"]:
            janela[key].update("")

janela.close()