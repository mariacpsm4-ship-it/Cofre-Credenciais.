-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 19/09/2026 às 02:47
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `credenciais`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `credenciais`
--

CREATE TABLE `credenciais` (
  `id` int(11) NOT NULL,
  `servico` text NOT NULL,
  `usuario` text NOT NULL,
  `senha` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `credenciais_cofre`
--

CREATE TABLE `credenciais_cofre` (
  `ID_Credenciais` int(11) NOT NULL,
  `servico` varchar(100) NOT NULL,
  `usuario` varchar(150) NOT NULL,
  `senha` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `credenciais_cofre`
--

INSERT INTO `credenciais_cofre` (`ID_Credenciais`, `servico`, `usuario`, `senha`) VALUES
(6, 'guithub', 'mariacrisemail.com', 'gAAAAABqpYNvoRY5USqYV2qdluTTuoqMcZeI-tZF6XPtrn_e8gQ0-MsyMXHhhWYR-zZuzjXaMuEvmfaRkmOQ8TZzYz9orHBy5A=='),
(8, 'github', 'brunamatos@gmail', 'gAAAAABqpuCOK5ShiApSgfsG-bEp4kUb4sMoBdyJGo4a4TtbEXBnCyUyfyrl163ezp1ffsNMsbDxYk3F4WSH2oWoWKphZEgt8A=='),
(9, 'github', 'giovana@gmail.com', 'gAAAAABqpvFoa3oIwApRZ4GeC8SGK0qpXztSDzvb0GhQuPI4oCztqsl-4iUJVQepKRm3J82u-VRIssn1b022Fnuh8vNjkzrfyQ=='),
(10, 'github', 'maria@crigmail.com', 'gAAAAABqrc2nM7twaYjqAQuJxPO0mlhY0iw7V2-fTM-1NIpfPu7J6ZxOlqURKZur0FRo9bMmsqiTk7Jp_h72Y3RLsDnGtkkmfw=='),
(11, 'github', 'gigi@senacsp.com', 'gAAAAABqrc5XpXMVN035th-irOFrpUb1Ya4t7rQFqFk8Sm8up9J31LRC-LAUGY252_NEYC6UQNLxF1bEzwACNIF8hkjTFsA1Lw==');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `credenciais`
--
ALTER TABLE `credenciais`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `credenciais_cofre`
--
ALTER TABLE `credenciais_cofre`
  ADD PRIMARY KEY (`ID_Credenciais`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `credenciais`
--
ALTER TABLE `credenciais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `credenciais_cofre`
--
ALTER TABLE `credenciais_cofre`
  MODIFY `ID_Credenciais` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
