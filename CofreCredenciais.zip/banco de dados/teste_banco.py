import mysql.connector


conexao = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="Credenciais"
)


cursor = conexao.cursor()


comando_sql = """
INSERT INTO Credenciais_Cofre
(servico, usuario, senha)
VALUES (%s, %s, %s)
"""


servico = input("Digite o serviço: ")
usuario = input("Digite o usuário: ")
senha = input("Digite a senha: ")


cursor.execute(
    comando_sql,
    (servico, usuario, senha)
)


conexao.commit()


print("Credencial cadastrada com sucesso!")
print("ID:", cursor.lastrowid)


cursor.close()
conexao.close()