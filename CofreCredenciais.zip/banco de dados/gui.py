import mysql.connector
import PySimpleGUI as sg
from cryptography.fernet import Fernet
try:
    with open("chave.key", "rb") as key_file:
        CHAVE = key_file.read()
except FileNotFoundError:
    CHAVE = Fernet.generate_key()
    with open("chave.key", "wb") as key_file:
        key_file.write(CHAVE)
 
cipher = Fernet(CHAVE)
 
def criptografar_senha(senha_plana):
    return cipher.encrypt(senha_plana.encode()).decode()
 
def decodificar_senha(senha_cripto):
    try:
        return cipher.decrypt(senha_cripto.encode()).decode()
    except Exception:
        return "[Erro na decodificação]"
 
 
def obter_conexao():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="Credenciais"
    )
 
def carregar_dados_do_banco():
    conexao = None
    cursor = None
    dados = []
    try:
        conexao = obter_conexao()
        cursor = conexao.cursor()
        cursor.execute("SELECT ID_Credenciais, servico, usuario FROM credenciais_cofre")
        dados = cursor.fetchall()
    except mysql.connector.Error as erro:
        print(f"Erro ao buscar dados: {erro}")
    finally:
        if cursor is not None:
            cursor.close()
        if conexao is not None and conexao.is_connected():
            conexao.close()
    return dados
 
 
sg.theme('DarkBlue3')
 
cabecalhos = ['ID', 'Serviço', 'Usuário']
 
layout = [
    [sg.Text("Serviço:", size=(8, 1)), sg.Input(key="-SERVICO-")],
    [sg.Text("Usuário:", size=(8, 1)), sg.Input(key="-USUARIO-")],
    [sg.Text("Senha:", size=(8, 1)), sg.Input(key="-SENHA-", password_char="*")],

    [sg.Button("Cadastrar"), sg.Button("Limpar"), sg.Button("Sair")],

    [sg.HorizontalSeparator()],

    [sg.Table(
        values=carregar_dados_do_banco(),
        headings=cabecalhos,
        max_col_width=25,
        auto_size_columns=True,
        justification='center',
        num_rows=10,
        key='-TABELA-',
        enable_events=True
    )],

    [sg.Button("Revelar Senha Selecionada", key="-REVELAR-"),
     sg.Button("Alterar Senha", key="-ALTERAR-"),
     sg.Button("Excluir", key="-EXCLUIR-")]
]

 
janela = sg.Window("Cofre de Credenciais", layout)
 
 
registro_selecionado_id = None
 
while True:
    evento, valores = janela.read()
    if evento == "-EXCLUIR-":
          if registro_selecionado_id is None:
            sg.popup("Selecione um registro na tabela primeiro!", title="Aviso")
          else:
            resposta = sg.popup_yes_no(
                "Tem certeza que deseja excluir este registro?",
                title="Confirmar exclusão"
            )

            if resposta == "Yes":
                conexao = None
                cursor = None

                try:
                    conexao = obter_conexao()
                    cursor = conexao.cursor()

                    cursor.execute(
                        "DELETE FROM credenciais_cofre WHERE ID_Credenciais = %s",
                        (registro_selecionado_id,)
                    )

                    conexao.commit()

                    sg.popup("Credencial excluída com sucesso!", title="Sucesso")

                    janela["-TABELA-"].update(
                        values=carregar_dados_do_banco()
                    )

                    registro_selecionado_id = None

                except mysql.connector.Error as erro:
                    sg.popup_error(f"Erro ao excluir: {erro}")

                        

                finally:
                   if cursor is not None:
                    cursor.close()

                    if conexao is not None and conexao.is_connected():
                        conexao.close()
 
    if evento in (sg.WINDOW_CLOSED, "Sair"):
        break
 
    if evento == "-TABELA-":
     if valores["-TABELA-"]:
        idx = valores["-TABELA-"][0]
        dados_tabela = carregar_dados_do_banco()

        if idx < len(dados_tabela):
            registro_selecionado_id = dados_tabela[idx][0]
 
    if evento == "Cadastrar":
        if not all([valores["-SERVICO-"], valores["-USUARIO-"], valores["-SENHA-"]]):
            sg.popup_error("Todos os campos são obrigatórios!")
            continue
 
        servico = valores["-SERVICO-"]
        usuario = valores["-USUARIO-"]
        senha_plana = valores["-SENHA-"]
 
        conexao = None
        cursor = None
 
        try:
            senha_mascarada = criptografar_senha(senha_plana)
 
            conexao = obter_conexao()
            cursor = conexao.cursor()
 
            sql = "INSERT INTO credenciais_cofre (servico, usuario, senha) VALUES (%s, %s, %s)"
            cursor.execute(sql, (servico, usuario, senha_mascarada))
            
            conexao.commit()
 
            sg.popup_ok("Cadastro inserido no banco com sucesso!")
 
            janela['-TABELA-'].update(values=carregar_dados_do_banco())
 
            for key in ["-SERVICO-", "-USUARIO-", "-SENHA-"]:
                janela[key].update("")
 
        except mysql.connector.Error as erro:
            sg.popup_error(f"ERRO AO CADASTRAR:\n\n{erro}")
 
        finally:
            if cursor is not None:
                cursor.close()
            if conexao is not None and conexao.is_connected():
                conexao.close()
 
    if evento == "-REVELAR-":
        if registro_selecionado_id is None:
            sg.popup("Selecione um registro na tabela primeiro!", title="Aviso")
        else:
            conexao = None
            cursor = None
            try:
                conexao = obter_conexao()
                cursor = conexao.cursor()
                cursor.execute("SELECT senha FROM credenciais_cofre WHERE ID_Credenciais = %s", (registro_selecionado_id,))
                resultado = cursor.fetchone()
                
                if resultado:
                    senha_cripto_banco = resultado[0]
                    senha_revelada = decodificar_senha(senha_cripto_banco)
                    sg.popup(f"Senha original: {senha_revelada}", title="Senha Revelada")
            except mysql.connector.Error as erro:
                sg.popup_error(f"Erro ao buscar senha: {erro}")
            finally:
                if cursor is not None:
                    cursor.close()
                if conexao is not None and conexao.is_connected():
                    conexao.close()
 
    if evento == "Limpar":
        for key in ["-SERVICO-", "-USUARIO-", "-SENHA-"]:
            janela[key].update("")
        registro_selecionado_id = None

    if evento == "-ALTERAR-":
        if registro_selecionado_id is None:
            sg.popup("Selecione um registro na tabela primeiro!", title="Aviso")
        else:
            nova_senha = sg.popup_get_text(
                "Digite a nova senha:",
                title="Alterar Senha",
                password_char="*"
            )

            if nova_senha:
                conexao = None
                cursor = None

                try:
                    senha_criptografada = criptografar_senha(nova_senha)

                    conexao = obter_conexao()
                    cursor = conexao.cursor()

                    sql = """
                    UPDATE credenciais_cofre
                    SET senha = %s
                    WHERE ID_Credenciais = %s
                    """

                    cursor.execute(
                        sql,
                        (senha_criptografada, registro_selecionado_id)
                    )

                    conexao.commit()

                    sg.popup(
                        "Senha alterada com sucesso!",
                        title="Sucesso"
                    )

                except mysql.connector.Error as erro:
                    sg.popup_error(
                        f"Erro ao alterar a senha:\n\n{erro}"
                    )

                finally:
                    if cursor is not None:
                        cursor.close()

                    if conexao is not None and conexao.is_connected():
                        conexao.close()

    if evento == "Limpar":
        for key in ["-SERVICO-", "-USUARIO-", "-SENHA-"]:
            janela[key].update("")
        registro_selecionado_id = None
 
janela.close()
 